#!/bin/bash
sudo ip link set up can1 type can bitrate 1000000
echo "DONE"
